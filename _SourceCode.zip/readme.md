AllMsg_ChatTitles.txt and ChatID_AllMsg.txt files are connected to each other

These two are based on message. If new message is sent in that specific channel then the message will be retreive.

Sample:
        AllMsg_ChatTitles.txt           ChatID_AllMsg.txt
        CRYPTETE                        -1001509043360

CRYPTETE is the title of Channel and CRYPTETE Channel is -1001509043360

To get Channel Title and ChatID/ChannelID forward message into https://t.me/getidsbot






PinMsg_ChatTitles.txt and ChatID_PinMsg.txt files are connected to each other

These two are based on pin message. If message is pinned then message will be retreive.

Sample:
        PinMsg_ChatTitles.txt           ChatID_PinMsg.txt
        CRYPTETE                        -1001509043360

CRYPTETE is the title of Channel and CRYPTETE Channel is -1001509043360

To get Channel Title and ChatID/ChannelID forward message into https://t.me/getidsbot